import React from 'react';

export default () => {
  return <div>user view</div>;
};
